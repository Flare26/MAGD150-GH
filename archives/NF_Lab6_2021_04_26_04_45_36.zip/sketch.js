//Nathan Frazier
  let tX= 0;
  let tY= 200;
  var angle = 0;
  var chdir = false;
function setup() {
  createCanvas(400, 400);
  print(displayWidth);
  print(width);

}

function draw() {
  background(color(34,0,102));
  angleMode(DEGREES);
  //print("tX: " + tX);
  push();
  strokeWeight(5);
  line(300, 330, 300, 400);
  pop();
  
  drawPinwheel(angle);
  angle += 15; // increment the degrees to rotate to
  
  // Duct-tape solution of setting the direction of the tornado
  if (tX > width && chdir == false)
    {
      chdir = true;
    }
  if (tX < 0 && chdir == true)
    {
      chdir = false;
    }
  // Tornado direction logic
  if (chdir == false)
    {
      tX += deltaTime/10;
    }
  if (chdir == true)
    {
      tX -= deltaTime/10;
    }
    
  
  drawTornado(tX, tY);
  for (var x = 0; x < width; x += 10)
    {
     drawCloudLayer(x, 10);   
    }
  


}

function drawCloudLayer(x, y)
{
  // make a cloud layer cover the top of the canvas
  push();
  noStroke();
  translate(x, y);
  
  cldscale = random(1, 2);
  
  scale(cldscale);
  fill(color(150)); 
  circle(x, y, 50);
  pop();
}

function drawPinwheel(angle)
{
  push();
  translate(300, 330);
  strokeWeight(5);
  stroke(color(255,102,179));
  fill(color(179,0,255)); 
  rotate(angle);
  rectMode(CENTER); // Rotate around the center NOT THE CORNER
  // transform sets the position for these shapes, so I can create them at 0,0 and they will
  // be all put in the same place on the canvas instead of the actual pixel coordinates 0,0
  rect(0, 0, 50, 50);
  line(0,0, 0, 30);
  line(0,0, 30, 0);
  line(0,0, -30, 0);
  line(0,0, 0, -30);
  pop();
}

function tornadoColor()
{
  var newcol = color(random(100));
  print("New color: " + newcol)
  return newcol;
}

function drawTornado(x, y)
{
  
  push(); 
  fill(tornadoColor());
  strokeWeight(6);
  stroke(color(100));
  translate(x - 30 , y); // This is translating the draw of the tornado in relation to the canvas
  //translate(p5.Vector.fromAngle(millis() / 1000, 40));
  triangle(0, 0,100, 5, 50,200);
  pop();
}