let a;
function preload()
{
  //preload runs once
  //images can be referenced using relative path
  img1 = loadImage("cyberpunki.jpg");
  img2 = loadImage("Judgement_Idle.gif");
}

function setup() {
  createCanvas(1920, 1080);
  img1.loadPixels();
  a = img1.get(img1.width / 2, img1.height / 2);
  textFont("New Tegomin");
}

function draw() {
  background(a);
  image(img1,0,0,1920,1080);
  textSize(48)
  
  image (img2, mouseX, mouseY);
  fill(color("white"));
  stroke(color('hotpink'));
  strokeWeight(24);
  text("Credit to CDPR for the background image and Heart Machine for the .GIF image.",width/2,height/4,750,1080);
}