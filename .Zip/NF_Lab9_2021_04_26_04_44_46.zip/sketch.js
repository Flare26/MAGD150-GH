//Nathan Frazier Lab 9
//Code volume control and create a record function if time permits?
// Look in to what tools there are to make an "eq"
/*Create or locate an audio file in the .wav, .aiff, or .mp3 format (10%)

 

Load an audio file (Links to an external site.) (.wav, .aiff, or .mp3) (note this requires The Google Web Server for Chome, there is more information on this extension in the Lab Assignment Eight description. (10%)

 

Play, pause or loop the audio file within your sketch. (10%)

 

Use the microphone (Links to an external site.) as an input for audio (10%)

 

Create shapes, lines, or points in your draw() method that animate based on the sound input from the microphone (10%)

 

Use the p5.Oscillator (Links to an external site.) to create a 'sine' wave sound (10%)

 

Create shapes, lines, or points in your draw() method that animate based on the 'sine' (Links to an external site.) wave sound. (10%)

 

Access the webcam (Links to an external site.) on your computer, sending the output to the browser window (10%)

 

Apply a filter (Links to an external site.) to the webcam video output (10%)

 

Create a .zip or .rar compressed version of your files, in a folder, and submit the assignment to Canvas. Include all of your files together so that they will run correctly when the folder is uncompressed (10%)*/

var x3osc; // Based on an plugin ailable in the free trial of FL Studio
let playing, freq, amp;
let osc0, osc1, osc2;
var file;
var mic;
var cam;

function preload()
{
  file = loadSound("CityMusic.ogg");
}

function setup() {
  //Initialize
  let cnv = createCanvas(400, 400);
  cnv.mousePressed(playOscillator);
  cam = createCapture(VIDEO);
  
  // Note: The triple S of electonic music
  osc0 = new p5.Oscillator('sine');
  osc1 = new p5.Oscillator('square');
  osc2 = new p5.Oscillator('sawtooth');
  mic = new p5.AudioIn();
  mic.start();
  //file.play();
  file.loop();
  x3osc = [osc0,osc1,osc2];
}

function draw() {
  background(220)
  freq = constrain(map(mouseX, 0, width, 100, 500), 100, 500);
  miclvl = mic.getLevel();
    push();
    image(cam, 0, 200, 150,150);
    filter(INVERT);
    pop();
    fill(color("green"));
    rect(150,250,miclvl * 750, 50); // mic level bar
  amp = constrain(map(mouseY, height, 0, 0, 1), 0, 1);
  
  text('Click to play oscillator', 20, 20);
  text('freq: ' + freq, 20, 40);
  text('amp: ' + amp, 20, 60);
  text ('mic lvl: ' + miclvl, 20, 80 )
  if (playing) {
    // smooth the transitions by 0.1 seconds
    for (var i = 0; i < x3osc.length; i++)
    {
    x3osc[i].freq(freq, 0.1);
    x3osc[i].amp(amp, 0.1);
    }

    
  }
}

function playOscillator() {
  // starting an oscillator on a user gesture will enable audio
  // in browsers that have a strict autoplay policy.
  // See also: userStartAudio();
    for (var i = 0; i < x3osc.length; i++)
  {
      osc0.start();
      osc1.start();
      osc2.start();
  }
  playing = true;
}

function mouseReleased() {
  // ramp amplitude to 0 over 0.5 seconds
  for (var i = 0; i < x3osc.length; i++)
  {
      osc0.amp(0, 0.5);
      osc1.amp(0, 0.5);
      osc2.amp(0, 0.5);
  }

  playing = false;
}