// Nathan Frazier
// menu that you can navigate with <- and -> arrow keys
// Way more complicated than it needs to be but the concept is there

var titleXs;
var texts;
var optionCol;
var selIdx;
var titleXs;// = [50, 150, 250, 350, 450];
var yAxis = 250;
var xres = 550;
var yres = 480;
var move = 0;
var lastMove = 0;
var favIdx;
var icnX1;
var icnX2;
var icnX3;

function setup() {
  createCanvas(xres, yres);
  frameRate(30); // limit the framerate for consistient deltaTime comparisons
  //initialize these
  titleXs = [50, 150 , 250, 350, 450];
  favIdx = 3;

  icnX1 = titleXs[favIdx] - 25;
  icnX2 = titleXs[favIdx] + 75;
  icnX3 = titleXs[favIdx] + 25;
  textSize(18);
  // names of games that these icons are representing
  texts = [text('Dig-Dug', titleXs[0], yAxis - 50), text('Galaga', titleXs[1], yAxis - 50),text('Pac-Man',   titleXs[2], yAxis - 50),text('Mappy', titleXs[3], yAxis - 50),text('Final Lap', titleXs[4], yAxis - 50) ]
  optionCol = [color('red'), color('green'), color('blue'), color('magenta'), color('orange')];
  
  print("Text Entries: " + texts.length);
  
}

function draw() {
  let tritarget = titleXs[favIdx] - 25;
  background(220);
  fill(color('gold'));
  // set position of favorite icon using tritarget
  if (icnX1 == tritarget + 1 && icnX1 == tritarget - 1 )
      {
              print("STOPPP");
      }
  else if (icnX1 != tritarget)
    {
      icnX1 += move;
      icnX2  += move
      icnX3 += move;
    } 

  icn = triangle(icnX1,50,icnX2,50,icnX3 ,125); // draw it
  move = 0; // reset move
  
  
  //print("titlesXs[favIdx]=" + titleXs[favIdx] );
  //print("X1=" + icnX1 + "X2=" + icnX2 + "X3="+icnX3);
  fill(color('black'));
  texts = [text('Dig-Dug', titleXs[0] - 5, yAxis - 50), text('Galaga', titleXs[1] - 5, yAxis - 50),text('Pac-Man',   titleXs[2] - 5, yAxis - 50),text('Mappy', titleXs[3] - 5, yAxis - 50),text('Final Lap', titleXs[4] - 5, yAxis - 50) ]
  optionCol = [color('red'), color('green'), color('blue'), color('magenta'), color('orange')];

  for (let i = 0; i < titleXs.length; i++)
    {         
      drawOption(titleXs[i], optionCol[i]);
      
      if (titleXs[i] == 250)
          {
             centerOption(optionCol[i]);
              selIdx = i;
          }
    }
  
  // adding + and - 1 to each to give the computer a range so if it measures within that range
  // it should act accordingly
  if ( icnX1 > tritarget + 2)
    {
      //print("fav moved left")
      // move triangle     
      move -= deltaTime / 2;
    } 
      else if (icnX1 < tritarget - 2) 
      {
      move += deltaTime / 2;
      }
  else if ((icnX1 < tritarget + 2) && (icnX1 > tritarget - 2))
    {
      move = 0;
      icnX1 = tritarget;
    }
  
  // these next two if statements prevents the favorite icon from spazzing out
  // it spazzes without these failsafes due to the program not being able to 
  // perfectly stop on the value I want.
  
  if (move < 0 && lastMove > 0)
    move = 0;
  
  if (move > 0 && lastMove < 0)
    move = 0;
  
  
  //print(move);

}

function keyPressed()
{
  if (keyCode == RIGHT_ARROW)
    {
      if (selIdx == titleXs.length - 1) // stop scroll at the last item
        return;
      
      print("LEFT");
      for (let i = 0; i < titleXs.length; i++)
        {
              titleXs[i] -= 100; // increment left 100 units
        }
    } else if (keyCode == LEFT_ARROW)
      {
       if (selIdx == 0) // stop scroll at the first item
        return;
        
        print("RIGHT");
        for (let i = 0; i < titleXs.length; i++)
          {
            titleXs[i] += 100; // increment right 100 units
          }
      }
  
}

function centerOption(col)
{
  push();
  translate(225, yAxis );
  // There is definitely a better way to do this but
  // for now I went with hard-wiring the coordinates
  fill(col);

  rect(0, 0, 100, 100);
  
  pop();

}

function drawOption(x, col)
{
  // executes for each individual
  push();
  fill(col);
  rect(x, yAxis, 50, 50);
  pop();
}